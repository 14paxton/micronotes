package com.example;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.micronaut.core.annotation.Introspected;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Introspected
public class GithubRelease {

    @NotBlank
    private String name;
    private String url;
    @JsonProperty("tag_name")
    private String tagName;
    @Email
    @JsonProperty("author_email")
    private String authorEmail;

    private String foo;

    public GithubRelease() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getFoo() {
        return foo;
    }

    public void setFoo(String foo) {
        this.foo = foo;
    }

    public String getAuthorEmail() {
        return authorEmail;
    }

    public void setAuthorEmail(String authorEmail) {
        this.authorEmail = authorEmail;
    }

    @Override
    public String toString() {
        return "GithubRelease{" +
                "name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", tagName='" + tagName + '\'' +
                ", authorEmail='" + authorEmail + '\'' +
                ", foo='" + foo + '\'' +
                '}';
    }
}
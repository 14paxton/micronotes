package com.example;

import io.micronaut.discovery.event.ServiceStoppedEvent;
import io.micronaut.runtime.event.annotation.EventListener;
import jakarta.inject.Singleton;

@Singleton
public class ShutdownListener {

    @EventListener
    void shutdownLogger(ServiceStoppedEvent serviceStoppedEvent) {
        System.out.println("Service is shut down!");
    }
}

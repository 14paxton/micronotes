package com.example;

import io.micronaut.discovery.event.ServiceReadyEvent;
import io.micronaut.runtime.event.annotation.EventListener;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class Bootstrap {

    @Inject
    GithubConfiguration githubConfiguration;

    @EventListener
    void ready(ServiceReadyEvent serviceReadyEvent) {
        System.out.println("Service is ready!");
        System.out.println(githubConfiguration.getOrganization());
        System.out.println(githubConfiguration.getRepo());
    }

}

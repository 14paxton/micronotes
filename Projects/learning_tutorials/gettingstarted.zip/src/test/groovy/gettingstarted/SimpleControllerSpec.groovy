package gettingstarted

import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import jakarta.inject.Inject

@MicronautTest
class SimpleControllerSpec extends Specification {

    @AutoCleanup
    @Shared
    @Inject
    @Client("/")
    HttpClient client

    void "test simple greeting action"() {
        expect:
        'Hello Jeff' == client.toBlocking().retrieve("/hello/Jeff")
    }
}
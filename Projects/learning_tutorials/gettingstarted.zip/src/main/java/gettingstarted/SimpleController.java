package gettingstarted;

// Annotate with @Controller
public class SimpleController {

    // Define controller action...
}

package com.example;

import io.micronaut.http.annotation.*;

@Controller("/swaggerdemo")
public class SwaggerdemoController {

    @Get(uri="/", produces="text/plain")
    public String index() {
        return "Example Response";
    }
}
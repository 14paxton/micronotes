package polyglotdemo

import io.micronaut.http.annotation.Controller
import io.micronaut.http.annotation.Get

@Controller("/kotlin")
class KotlinHelloController(
    private var greeter: Greeter
) {

    @Get("/hello/{name}")
    fun hello(name: String): String {
        return greeter.greet(name, "Kotlin")
    }
}
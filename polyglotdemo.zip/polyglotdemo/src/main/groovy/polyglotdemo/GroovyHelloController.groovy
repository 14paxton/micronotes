package polyglotdemo

import io.micronaut.http.annotation.Controller
import io.micronaut.http.annotation.Get
import jakarta.inject.Inject

@Controller('/groovy')
class GroovyHelloController {

    @Inject
    Greeter greeter

    @Get('/hello/{name}')
    String hello(String name) {
        greeter.greet(name, "Groovy")
    }
}

package polyglotdemo;

import jakarta.inject.Singleton;

@Singleton
public class Greeter {

    String greet(String name, String source) {
        return "Hello " + name + " from " + source + "!";
    }
}

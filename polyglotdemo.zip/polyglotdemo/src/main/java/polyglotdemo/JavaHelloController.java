package polyglotdemo;

import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;

@Controller("/java")
public class JavaHelloController {

    Greeter greeter;

    public JavaHelloController(Greeter greeter) {
        this.greeter = greeter;
    }

    @Get("/hello/{name}")
    public String hello(String name) {
        return greeter.greet(name, "Java");
    }
}

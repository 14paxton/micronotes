package polyglotdemo

import io.micronaut.http.HttpRequest
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification

import jakarta.inject.Inject

@MicronautTest
class HelloControllersSpec extends Specification {

    @Shared
    @AutoCleanup
    @Inject
    @Client('/')
    HttpClient client

    void 'test polyglot greetings'() {
        expect:
        client.toBlocking().retrieve(HttpRequest.GET('/groovy/hello/Keith')) == 'Hello Keith From Groovy'
        client.toBlocking().retrieve(HttpRequest.GET('/java/hello/Carl')) == 'Hello Carl From Java'
        client.toBlocking().retrieve(HttpRequest.GET('/kotlin/hello/Greg')) == 'Hello Greg From Kotlin'
    }
}
